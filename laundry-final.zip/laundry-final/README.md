# 🧺 CleanTrack v2 — Laundry Order Management System

A dual-portal dry cleaning management system with separate **Customer** and **Owner** experiences.

---

## 🚀 Setup Instructions

### Prerequisites: Node.js v16+

### 1. Start Backend
```bash
cd backend
npm install
npm start
# ✅ Runs on http://localhost:5000
```

### 2. Start Frontend
```bash
cd frontend
npm install
npm start
# ✅ Opens on http://localhost:3000
```

### Demo Credentials
| Role     | Email                    | Password  |
|----------|--------------------------|-----------|
| Owner    | owner@cleantrack.com     | owner123  |
| Customer | rahul@example.com        | user123   |
| Customer | priya@example.com        | user456   |

---

## ✅ Features Implemented

### 📋 Assignment Requirements (PDF)
| Requirement | Status |
|---|---|
| Create Order (Name, Phone, Garments, Qty, Price) | ✅ |
| Unique Order ID | ✅ |
| Total Bill Calculation | ✅ |
| Status: RECEIVED → PROCESSING → READY → DELIVERED | ✅ |
| Update Order Status | ✅ |
| List All Orders | ✅ |
| Filter by Status | ✅ |
| Filter by Customer Name / Phone | ✅ |
| Dashboard (Total Orders, Revenue, Orders per Status) | ✅ |
| Estimated Delivery Date (Bonus) | ✅ |
| Simple Frontend (Bonus) | ✅ |
| Search by Garment Type (Bonus) | ✅ |

### 👤 Customer Portal
- Register & Login
- Place new orders (dynamic garment selection)
- Track active orders with live status + timeline
- Full order history (delivered orders)
- Give feedback — Overall Rating, Product Quality, Service Rating
- View past feedback

### 🏪 Owner Portal
- Dashboard — total orders, revenue, status breakdown, avg ratings
- All Orders — full table with multi-filter search
- Manage Status — move orders through workflow, confirm delivery
- Garment Management — add/edit/activate/deactivate garments + prices
- Feedback View — all customer reviews with rating summary
- Customer List — all registered users

---

## 📡 API Reference

### Auth
| Method | Endpoint | Description |
|---|---|---|
| POST | /auth/register | Register new user |
| POST | /auth/login | Login (user or owner) |

### Garments
| Method | Endpoint | Description |
|---|---|---|
| GET | /garments | Active garments (for users) |
| GET | /garments/all | All garments (for owner) |
| POST | /garments | Add new garment |
| PATCH | /garments/:id | Edit garment |
| DELETE | /garments/:id | Deactivate garment |

### Orders
| Method | Endpoint | Description |
|---|---|---|
| POST | /orders | Create order |
| GET | /orders | List (supports ?userId, ?status, ?customerName, ?phone, ?garmentType) |
| GET | /orders/:orderId | Get single order |
| PATCH | /orders/:orderId/status | Update status |
| PATCH | /orders/:orderId/confirm | Confirm delivery |
| DELETE | /orders/:orderId | Delete order |

### Feedback
| Method | Endpoint | Description |
|---|---|---|
| POST | /feedback | Submit feedback |
| GET | /feedback | All feedback (owner) |
| GET | /feedback/order/:orderId | Feedback for one order |
| GET | /feedback/user/:userId | User's feedback history |

### Dashboard
| Method | Endpoint |
|---|---|
| GET | /dashboard |

---

## 🤖 AI Usage Report

### Tools Used: Claude (Anthropic), GitHub Copilot

### Sample Prompts
1. *"Build a Node.js Express backend for a laundry system with in-memory storage, user/owner auth, order CRUD, status history, feedback with separate product/service ratings, garment management, and a dashboard endpoint."*
2. *"Build a React frontend with two separate portals — Customer (order, track, history, feedback) and Owner (dashboard, manage orders, garments, view feedback). Dark minimal aesthetic, sidebar layout, no CSS libraries."*
3. *"Add a status timeline component showing each status change with timestamp and note."*

### What AI Got Right ✅
- Entire Express server structure in one shot
- React component separation between portals
- Status history array with push on each update
- Dashboard aggregation logic

### What AI Got Wrong / Fixed 🛠
1. **Missing CORS** — Had to add `app.use(cors())` manually
2. **Feedback uniqueness check** — AI allowed duplicate feedback per order, added check
3. **Status badge dark theme** — AI used light bg colors, fixed for dark theme contrast
4. **Modal click-outside** — `e.stopPropagation()` was missing on modal inner box
5. **Order filter chaining** — AI used `if/else` instead of chained `.filter()`, refactored

---

## ⚖️ Tradeoffs

### Skipped
- Persistent database (using in-memory, resets on restart)
- JWT tokens (using simple email/password returned object)
- Pagination on order lists

### Would Improve With More Time
- MongoDB / PostgreSQL for persistence
- JWT auth with refresh tokens
- Email/SMS notification when order is READY
- Order edit (change items before PROCESSING)
- Analytics charts (revenue over time)
- Deploy on Railway + Vercel

---

## 📁 Structure
```
laundry-final/
├── backend/
│   ├── server.js       ← All API routes & logic
│   └── package.json
├── frontend/
│   ├── public/index.html
│   ├── src/
│   │   ├── App.js      ← Complete React app (Auth + User + Owner portals)
│   │   └── index.js
│   └── package.json
└── README.md
```
