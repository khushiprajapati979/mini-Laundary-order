const express = require("express");
const cors = require("cors");
const { v4: uuidv4 } = require("uuid");

const app = express();
app.use(cors());
app.use(express.json());

// ═══════════════════════════════════════════════════
// IN-MEMORY DATA STORE
// ═══════════════════════════════════════════════════

let users = [
  { id: "u1", name: "Rahul Sharma", phone: "9876543210", email: "rahul@example.com", password: "user123", role: "user", createdAt: new Date().toISOString() },
  { id: "u2", name: "Priya Verma",  phone: "9123456789", email: "priya@example.com", password: "user456", role: "user", createdAt: new Date().toISOString() },
];

let owners = [
  { id: "o1", name: "Shop Owner", email: "owner@cleantrack.com", password: "owner123", role: "owner" },
];

let garments = [
  { id: "g1",  name: "Shirt",     price: 50,  active: true },
  { id: "g2",  name: "Pants",     price: 60,  active: true },
  { id: "g3",  name: "Saree",     price: 150, active: true },
  { id: "g4",  name: "Suit",      price: 200, active: true },
  { id: "g5",  name: "Jacket",    price: 120, active: true },
  { id: "g6",  name: "Dress",     price: 100, active: true },
  { id: "g7",  name: "Kurta",     price: 70,  active: true },
  { id: "g8",  name: "Jeans",     price: 80,  active: true },
  { id: "g9",  name: "Sweater",   price: 90,  active: true },
  { id: "g10", name: "Bedsheet",  price: 130, active: true },
];

let orders   = [];
let feedback = [];

const STATUSES = ["RECEIVED", "PROCESSING", "READY", "DELIVERED"];

// ─── Helpers ──────────────────────────────────────
function uid(p) { return p + "-" + uuidv4().slice(0, 8).toUpperCase(); }
function deliveryDate() {
  const d = new Date(); d.setDate(d.getDate() + 2);
  return d.toISOString().split("T")[0];
}
function calcBill(items) {
  return items.reduce((s, i) => s + i.pricePerItem * i.quantity, 0);
}

// ═══════════════════════════════════════════════════
// AUTH
// ═══════════════════════════════════════════════════

// POST /auth/register
app.post("/auth/register", (req, res) => {
  const { name, phone, email, password } = req.body;
  if (!name || !phone || !email || !password)
    return res.status(400).json({ error: "All fields required" });
  if ([...users, ...owners].find(u => u.email === email))
    return res.status(400).json({ error: "Email already registered" });
  const user = { id: uid("USR"), name, phone, email, password, role: "user", createdAt: new Date().toISOString() };
  users.push(user);
  const { password: _, ...safe } = user;
  res.status(201).json({ message: "Registered successfully", user: safe });
});

// POST /auth/login
app.post("/auth/login", (req, res) => {
  const { email, password } = req.body;
  const person = [...users, ...owners].find(u => u.email === email && u.password === password);
  if (!person) return res.status(401).json({ error: "Invalid email or password" });
  const { password: _, ...safe } = person;
  res.json({ message: "Login successful", user: safe });
});

// ═══════════════════════════════════════════════════
// GARMENTS — owner manages, users view
// ═══════════════════════════════════════════════════

// GET /garments — active garments for users
app.get("/garments", (_req, res) => res.json(garments.filter(g => g.active)));

// GET /garments/all — all garments for owner
app.get("/garments/all", (_req, res) => res.json(garments));

// POST /garments — owner adds garment
app.post("/garments", (req, res) => {
  const { name, price } = req.body;
  if (!name || !price) return res.status(400).json({ error: "name and price required" });
  if (garments.find(g => g.name.toLowerCase() === name.toLowerCase() && g.active))
    return res.status(400).json({ error: "Garment already exists" });
  const g = { id: uid("GRM"), name, price: Number(price), active: true, createdAt: new Date().toISOString() };
  garments.push(g);
  res.status(201).json(g);
});

// PATCH /garments/:id — owner edits
app.patch("/garments/:id", (req, res) => {
  const g = garments.find(g => g.id === req.params.id);
  if (!g) return res.status(404).json({ error: "Not found" });
  if (req.body.name  !== undefined) g.name   = req.body.name;
  if (req.body.price !== undefined) g.price  = Number(req.body.price);
  if (req.body.active!== undefined) g.active = req.body.active;
  res.json(g);
});

// DELETE /garments/:id
app.delete("/garments/:id", (req, res) => {
  const g = garments.find(g => g.id === req.params.id);
  if (!g) return res.status(404).json({ error: "Not found" });
  g.active = false;
  res.json({ message: "Garment removed" });
});

// ═══════════════════════════════════════════════════
// ORDERS
// ═══════════════════════════════════════════════════

// POST /orders — user/owner creates order
app.post("/orders", (req, res) => {
  const { userId, customerName, phoneNumber, items, notes } = req.body;
  if (!customerName || !phoneNumber || !items || !items.length)
    return res.status(400).json({ error: "customerName, phoneNumber, and items required" });

  for (const i of items) {
    if (!i.name || !i.quantity || i.quantity < 1)
      return res.status(400).json({ error: "Each item needs name and quantity" });
  }

  const enriched = items.map(i => {
    const g = garments.find(g => g.name.toLowerCase() === i.name.toLowerCase());
    return {
      garmentId:    g?.id || null,
      name:         i.name,
      quantity:     Number(i.quantity),
      pricePerItem: g?.price || Number(i.pricePerItem) || 50,
    };
  });

  const order = {
    orderId:           uid("ORD"),
    userId:            userId || null,
    customerName,
    phoneNumber,
    items:             enriched,
    totalBill:         calcBill(enriched),
    status:            "RECEIVED",
    statusHistory:     [{ status: "RECEIVED", time: new Date().toISOString(), note: "Order placed" }],
    notes:             notes || "",
    estimatedDelivery: deliveryDate(),
    createdAt:         new Date().toISOString(),
    updatedAt:         new Date().toISOString(),
    deliveredAt:       null,
    deliveryConfirmed: false,
    hasFeedback:       false,
  };
  orders.push(order);
  res.status(201).json({ message: "Order created successfully", order });
});

// GET /orders — filtered list
app.get("/orders", (req, res) => {
  const { userId, status, customerName, phone, garmentType } = req.query;
  let result = [...orders];
  if (userId)       result = result.filter(o => o.userId === userId);
  if (status)       result = result.filter(o => o.status === status.toUpperCase());
  if (customerName) result = result.filter(o => o.customerName.toLowerCase().includes(customerName.toLowerCase()));
  if (phone)        result = result.filter(o => o.phoneNumber.includes(phone));
  if (garmentType)  result = result.filter(o => o.items.some(i => i.name.toLowerCase().includes(garmentType.toLowerCase())));
  result.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json({ total: result.length, orders: result });
});

// GET /orders/:orderId
app.get("/orders/:orderId", (req, res) => {
  const o = orders.find(o => o.orderId === req.params.orderId);
  if (!o) return res.status(404).json({ error: "Order not found" });
  res.json(o);
});

// PATCH /orders/:orderId/status — owner updates status
app.patch("/orders/:orderId/status", (req, res) => {
  const { status, note } = req.body;
  if (!STATUSES.includes((status || "").toUpperCase()))
    return res.status(400).json({ error: `Status must be: ${STATUSES.join(", ")}` });
  const o = orders.find(o => o.orderId === req.params.orderId);
  if (!o) return res.status(404).json({ error: "Order not found" });
  o.status    = status.toUpperCase();
  o.updatedAt = new Date().toISOString();
  o.statusHistory.push({ status: o.status, time: new Date().toISOString(), note: note || "" });
  if (o.status === "DELIVERED") {
    o.deliveredAt       = new Date().toISOString();
    o.deliveryConfirmed = true;
  }
  res.json({ message: "Status updated", order: o });
});

// PATCH /orders/:orderId/confirm — owner confirms delivery after dispatch
app.patch("/orders/:orderId/confirm", (req, res) => {
  const o = orders.find(o => o.orderId === req.params.orderId);
  if (!o) return res.status(404).json({ error: "Order not found" });
  o.deliveryConfirmed = true;
  o.status            = "DELIVERED";
  o.deliveredAt       = new Date().toISOString();
  o.updatedAt         = new Date().toISOString();
  o.statusHistory.push({ status: "DELIVERED", time: new Date().toISOString(), note: "Delivery confirmed by owner" });
  res.json({ message: "Delivery confirmed", order: o });
});

// DELETE /orders/:orderId
app.delete("/orders/:orderId", (req, res) => {
  const idx = orders.findIndex(o => o.orderId === req.params.orderId);
  if (idx === -1) return res.status(404).json({ error: "Order not found" });
  orders.splice(idx, 1);
  res.json({ message: "Order deleted" });
});

// ═══════════════════════════════════════════════════
// FEEDBACK
// ═══════════════════════════════════════════════════

// POST /feedback
app.post("/feedback", (req, res) => {
  const { userId, orderId, overallRating, productRating, serviceRating, comment } = req.body;
  if (!orderId || !overallRating)
    return res.status(400).json({ error: "orderId and overallRating required" });
  const order = orders.find(o => o.orderId === orderId);
  if (!order) return res.status(404).json({ error: "Order not found" });
  if (feedback.find(f => f.orderId === orderId))
    return res.status(400).json({ error: "Feedback already given for this order" });

  const fb = {
    id:             uid("FBK"),
    userId:         userId || null,
    orderId,
    customerName:   order.customerName,
    overallRating:  Number(overallRating),
    productRating:  Number(productRating  || overallRating),
    serviceRating:  Number(serviceRating  || overallRating),
    comment:        comment || "",
    createdAt:      new Date().toISOString(),
  };
  feedback.push(fb);
  order.hasFeedback = true;
  res.status(201).json({ message: "Feedback submitted", feedback: fb });
});

// GET /feedback — owner sees all
app.get("/feedback", (_req, res) => {
  const result = feedback.map(f => ({ ...f, order: orders.find(o => o.orderId === f.orderId) }));
  res.json({ total: result.length, feedback: result });
});

// GET /feedback/order/:orderId
app.get("/feedback/order/:orderId", (req, res) => {
  const fb = feedback.find(f => f.orderId === req.params.orderId);
  res.json(fb || null);
});

// GET /feedback/user/:userId
app.get("/feedback/user/:userId", (req, res) => {
  res.json(feedback.filter(f => f.userId === req.params.userId));
});

// ═══════════════════════════════════════════════════
// DASHBOARD — owner
// ═══════════════════════════════════════════════════
app.get("/dashboard", (_req, res) => {
  const totalOrders      = orders.length;
  const totalRevenue     = orders.reduce((s, o) => s + o.totalBill, 0);
  const ordersPerStatus  = STATUSES.reduce((a, s) => { a[s] = orders.filter(o => o.status === s).length; return a; }, {});
  const pendingDelivery  = orders.filter(o => o.status === "READY").length;
  const totalUsers       = users.length;
  const avgOverall       = feedback.length ? (feedback.reduce((s, f) => s + f.overallRating, 0) / feedback.length).toFixed(1) : null;
  const avgProduct       = feedback.length ? (feedback.reduce((s, f) => s + f.productRating,  0) / feedback.length).toFixed(1) : null;
  const avgService       = feedback.length ? (feedback.reduce((s, f) => s + f.serviceRating,  0) / feedback.length).toFixed(1) : null;
  const recentOrders     = [...orders].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 6);
  const recentFeedback   = [...feedback].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 5);
  res.json({ totalOrders, totalRevenue, ordersPerStatus, pendingDelivery, totalUsers, avgOverall, avgProduct, avgService, recentOrders, recentFeedback });
});

// GET /users — owner sees all users
app.get("/users", (_req, res) => res.json(users.map(({ password: _, ...u }) => u)));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🧺 CleanTrack API running → http://localhost:${PORT}`));
