import { useState, useEffect, useCallback } from "react";

const API = "http://localhost:5000";

/* ═══════════════════════════════════════════════════════════
   DESIGN TOKENS
═══════════════════════════════════════════════════════════ */
const T = {
  bg:      "#07070F",
  surf:    "#0D0D1A",
  card:    "#111120",
  border:  "#1C1C30",
  b2:      "#252540",
  accent:  "#6C63FF",
  aLight:  "#9B94FF",
  gold:    "#FFB547",
  green:   "#00D68F",
  red:     "#FF4D6D",
  blue:    "#4DA6FF",
  text:    "#EAE8FF",
  muted:   "#6E6B9A",
  dim:     "#32304A",
};

const STATUS = {
  RECEIVED:   { color: T.gold,  bg: "#FFB54715", icon: "📥", next: "PROCESSING" },
  PROCESSING: { color: T.blue,  bg: "#4DA6FF15", icon: "⚙️",  next: "READY"      },
  READY:      { color: T.green, bg: "#00D68F15", icon: "✅", next: "DELIVERED"   },
  DELIVERED:  { color: T.muted, bg: "#6E6B9A15", icon: "🚚", next: null          },
};

/* ═══════════════════════════════════════════════════════════
   STYLE HELPERS
═══════════════════════════════════════════════════════════ */
const inp = (extra={}) => ({
  width:"100%", padding:"11px 14px",
  background:"#090915", border:`1px solid ${T.border}`,
  borderRadius:"10px", color:T.text, fontSize:"14px",
  outline:"none", boxSizing:"border-box",
  fontFamily:"inherit", transition:"border .2s",
  ...extra,
});
const lbl = { fontSize:"11px", color:T.muted, marginBottom:"6px",
  display:"block", letterSpacing:"1px", textTransform:"uppercase" };
const card = (extra={}) => ({
  background:T.card, border:`1px solid ${T.border}`,
  borderRadius:"14px", padding:"22px", ...extra,
});
const btn = (v="primary", extra={}) => ({
  padding:"10px 20px", borderRadius:"10px", border:"none",
  cursor:"pointer", fontSize:"14px", fontWeight:600,
  fontFamily:"inherit", transition:"all .15s",
  background:
    v==="primary" ? `linear-gradient(135deg,${T.accent},${T.aLight})` :
    v==="green"   ? `linear-gradient(135deg,${T.green},#34D399)` :
    v==="danger"  ? `${T.red}20` : T.b2,
  color:
    v==="primary" ? "#fff" :
    v==="green"   ? "#041A0F" :
    v==="danger"  ? T.red : T.text,
  border: v==="danger" ? `1px solid ${T.red}30` : "none",
  boxShadow: v==="primary" ? `0 0 24px ${T.accent}40` : "none",
  ...extra,
});
const badge = (status) => ({
  display:"inline-flex", alignItems:"center", gap:5,
  padding:"4px 12px", borderRadius:"20px", fontSize:"11px", fontWeight:700,
  background: STATUS[status]?.bg || T.b2,
  color:      STATUS[status]?.color || T.muted,
});

/* ═══════════════════════════════════════════════════════════
   SMALL SHARED COMPONENTS
═══════════════════════════════════════════════════════════ */
function Toast({ msg, show }) {
  return (
    <div style={{
      position:"fixed", bottom:24, right:24, zIndex:999,
      background: msg?.startsWith("❌") ? T.red : T.green,
      color:"#fff", padding:"12px 20px", borderRadius:"10px",
      fontSize:"14px", fontWeight:600,
      boxShadow:`0 4px 24px ${msg?.startsWith("❌") ? T.red : T.green}50`,
      transform: show ? "translateY(0)" : "translateY(80px)",
      opacity: show ? 1 : 0, transition:"all .3s",
    }}>{msg}</div>
  );
}

function Stars({ value, onChange, size=22 }) {
  return (
    <div style={{ display:"flex", gap:4 }}>
      {[1,2,3,4,5].map(s => (
        <span key={s}
          onClick={() => onChange && onChange(s)}
          style={{ fontSize:size, cursor:onChange?"pointer":"default",
            filter: s <= value ? "none" : "grayscale(1) opacity(.3)" }}>
          ⭐
        </span>
      ))}
    </div>
  );
}

function Modal({ children, onClose }) {
  return (
    <div onClick={onClose} style={{
      position:"fixed", inset:0, background:"#000000CC",
      display:"flex", alignItems:"center", justifyContent:"center",
      zIndex:500, backdropFilter:"blur(6px)",
    }}>
      <div onClick={e=>e.stopPropagation()} style={{
        ...card(), width:520, maxWidth:"95vw", maxHeight:"88vh",
        overflowY:"auto", border:`1px solid ${T.b2}`,
      }}>
        {children}
      </div>
    </div>
  );
}

function StatusTimeline({ history }) {
  return (
    <div style={{ position:"relative", paddingLeft:24, marginTop:8 }}>
      {history.map((h, i) => (
        <div key={i} style={{ position:"relative", paddingBottom:16, paddingLeft:16 }}>
          <div style={{
            position:"absolute", left:-8, top:3, width:16, height:16,
            borderRadius:"50%", background: STATUS[h.status]?.color || T.muted,
            border:`2px solid ${T.bg}`, zIndex:1,
          }}/>
          {i < history.length-1 && (
            <div style={{ position:"absolute", left:-1, top:18,
              width:2, height:"100%", background:T.border }} />
          )}
          <div style={{ display:"flex", gap:12, alignItems:"baseline" }}>
            <span style={{ fontSize:12, fontWeight:700, color: STATUS[h.status]?.color }}>
              {STATUS[h.status]?.icon} {h.status}
            </span>
            <span style={{ fontSize:11, color:T.muted }}>
              {new Date(h.time).toLocaleString()}
            </span>
          </div>
          {h.note && <div style={{ fontSize:12, color:T.muted, marginTop:2 }}>{h.note}</div>}
        </div>
      ))}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   AUTH SCREEN
═══════════════════════════════════════════════════════════ */
function AuthScreen({ onLogin, showToast }) {
  const [mode, setMode]   = useState("login"); // login | register
  const [role, setRole]   = useState("user");
  const [form, setForm]   = useState({ name:"", phone:"", email:"", password:"" });
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    setLoading(true);
    try {
      if (mode === "login") {
        const r = await fetch(`${API}/auth/login`, {
          method:"POST", headers:{"Content-Type":"application/json"},
          body: JSON.stringify({ email:form.email, password:form.password }),
        });
        const d = await r.json();
        if (!r.ok) return showToast("❌ "+d.error);
        onLogin(d.user);
      } else {
        const r = await fetch(`${API}/auth/register`, {
          method:"POST", headers:{"Content-Type":"application/json"},
          body: JSON.stringify(form),
        });
        const d = await r.json();
        if (!r.ok) return showToast("❌ "+d.error);
        showToast("✅ Registered! Please login.");
        setMode("login");
      }
    } finally { setLoading(false); }
  };

  return (
    <div style={{
      minHeight:"100vh", background:T.bg,
      display:"flex", alignItems:"center", justifyContent:"center",
      fontFamily:"'Outfit',sans-serif",
    }}>
      {/* bg glow */}
      <div style={{ position:"fixed", top:"20%", left:"30%", width:400, height:400,
        background:`radial-gradient(circle, ${T.accent}20 0%, transparent 70%)`,
        pointerEvents:"none" }} />

      <div style={{ width:420, padding:"0 16px" }}>
        {/* Logo */}
        <div style={{ textAlign:"center", marginBottom:36 }}>
          <div style={{ fontSize:40, marginBottom:8 }}>🧺</div>
          <div style={{ fontFamily:"'Syne',sans-serif", fontSize:28, fontWeight:800, color:T.text }}>
            CleanTrack
          </div>
          <div style={{ fontSize:13, color:T.muted, marginTop:4, letterSpacing:1 }}>
            LAUNDRY MANAGEMENT SYSTEM
          </div>
        </div>

        {/* Role tabs */}
        <div style={{ display:"flex", background:T.surf, borderRadius:12, padding:4, marginBottom:24, border:`1px solid ${T.border}` }}>
          {["user","owner"].map(r => (
            <button key={r} onClick={()=>setRole(r)} style={{
              flex:1, padding:"9px", borderRadius:9, border:"none",
              cursor:"pointer", fontSize:14, fontWeight:600, fontFamily:"inherit",
              background: role===r ? T.accent : "transparent",
              color: role===r ? "#fff" : T.muted,
              transition:"all .2s",
            }}>
              {r==="user" ? "👤 Customer" : "🏪 Owner"}
            </button>
          ))}
        </div>

        {/* Card */}
        <div style={{ ...card(), border:`1px solid ${T.b2}` }}>
          <div style={{ display:"flex", gap:12, marginBottom:24 }}>
            {["login","register"].map(m => (
              mode !== "owner" && (
                <button key={m} onClick={()=>setMode(m)} style={{
                  flex:1, padding:"8px", borderRadius:8, border:"none",
                  cursor:"pointer", fontSize:13, fontWeight:600, fontFamily:"inherit",
                  background: mode===m ? T.b2 : "transparent",
                  color: mode===m ? T.text : T.muted,
                  display: role==="owner" && m==="register" ? "none" : "block",
                }}>
                  {m==="login" ? "Sign In" : "Register"}
                </button>
              )
            ))}
          </div>

          {mode==="register" && role==="user" && (
            <>
              <div style={{ marginBottom:14 }}>
                <label style={lbl}>FULL NAME</label>
                <input style={inp()} placeholder="Rahul Sharma"
                  value={form.name} onChange={e=>setForm({...form,name:e.target.value})} />
              </div>
              <div style={{ marginBottom:14 }}>
                <label style={lbl}>PHONE</label>
                <input style={inp()} placeholder="9876543210"
                  value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} />
              </div>
            </>
          )}

          <div style={{ marginBottom:14 }}>
            <label style={lbl}>EMAIL</label>
            <input style={inp()} placeholder={role==="owner"?"owner@cleantrack.com":"rahul@example.com"}
              value={form.email} onChange={e=>setForm({...form,email:e.target.value})} />
          </div>
          <div style={{ marginBottom:22 }}>
            <label style={lbl}>PASSWORD</label>
            <input style={inp()} type="password" placeholder="••••••••"
              value={form.password} onChange={e=>setForm({...form,password:e.target.value})} />
          </div>

          <button style={{ ...btn("primary"), width:"100%", padding:"13px" }}
            onClick={submit} disabled={loading}>
            {loading ? "Please wait..." : mode==="login" ? "Sign In →" : "Create Account →"}
          </button>

          {role==="owner" && (
            <div style={{ marginTop:14, padding:"10px 14px", background:`${T.accent}10`,
              borderRadius:8, fontSize:12, color:T.muted, border:`1px solid ${T.accent}20` }}>
              🔑 Demo — Email: <b style={{color:T.aLight}}>owner@cleantrack.com</b> / Pass: <b style={{color:T.aLight}}>owner123</b>
            </div>
          )}
          {role==="user" && mode==="login" && (
            <div style={{ marginTop:14, padding:"10px 14px", background:`${T.gold}10`,
              borderRadius:8, fontSize:12, color:T.muted, border:`1px solid ${T.gold}20` }}>
              🔑 Demo — Email: <b style={{color:T.gold}}>rahul@example.com</b> / Pass: <b style={{color:T.gold}}>user123</b>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   USER PORTAL
═══════════════════════════════════════════════════════════ */
function UserPortal({ user, onLogout, showToast }) {
  const [page, setPage]       = useState("home");
  const [garments, setGarments] = useState([]);
  const [myOrders, setMyOrders] = useState([]);
  const [selOrder, setSelOrder] = useState(null);

  const fetchGarments = useCallback(()=>{
    fetch(`${API}/garments`).then(r=>r.json()).then(setGarments).catch(()=>{});
  },[]);

  const fetchOrders = useCallback(()=>{
    fetch(`${API}/orders?userId=${user.id}`).then(r=>r.json()).then(d=>setMyOrders(d.orders||[])).catch(()=>{});
  },[user.id]);

  useEffect(()=>{ fetchGarments(); },[fetchGarments]);
  useEffect(()=>{ if(page==="orders"||page==="home") fetchOrders(); },[page,fetchOrders]);

  const nav = [
    { id:"home",     icon:"🏠", label:"Home"        },
    { id:"order",    icon:"➕", label:"New Order"    },
    { id:"orders",   icon:"📦", label:"My Orders"    },
    { id:"history",  icon:"🕐", label:"History"      },
    { id:"feedback", icon:"⭐", label:"My Feedback"  },
  ];

  return (
    <div style={{ minHeight:"100vh", background:T.bg, fontFamily:"'Outfit',sans-serif", display:"flex" }}>
      {/* Sidebar */}
      <aside style={{
        width:220, background:T.surf, borderRight:`1px solid ${T.border}`,
        display:"flex", flexDirection:"column", position:"fixed",
        top:0, left:0, height:"100vh", zIndex:100,
      }}>
        <div style={{ padding:"24px 20px 16px", borderBottom:`1px solid ${T.border}` }}>
          <div style={{ fontFamily:"'Syne',sans-serif", fontSize:18, fontWeight:800, color:T.text }}>
            🧺 CleanTrack
          </div>
          <div style={{ fontSize:11, color:T.muted, marginTop:3, letterSpacing:1 }}>CUSTOMER PORTAL</div>
        </div>
        <div style={{ padding:"12px", flex:1 }}>
          {nav.map(n=>(
            <div key={n.id} onClick={()=>setPage(n.id)} style={{
              display:"flex", alignItems:"center", gap:10, padding:"10px 12px",
              borderRadius:10, cursor:"pointer", marginBottom:3,
              background: page===n.id ? `${T.accent}20` : "transparent",
              color: page===n.id ? T.aLight : T.muted,
              fontWeight: page===n.id ? 600 : 400, fontSize:14,
              border: page===n.id ? `1px solid ${T.accent}30` : "1px solid transparent",
              transition:"all .15s",
            }}>
              <span>{n.icon}</span><span>{n.label}</span>
            </div>
          ))}
        </div>
        <div style={{ padding:"16px 20px", borderTop:`1px solid ${T.border}` }}>
          <div style={{ fontSize:13, color:T.text, fontWeight:600 }}>{user.name}</div>
          <div style={{ fontSize:11, color:T.muted, marginTop:2 }}>{user.phone}</div>
          <button onClick={onLogout} style={{ ...btn("danger",{padding:"6px 14px", fontSize:12, marginTop:10, width:"100%" }) }}>
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main */}
      <main style={{ marginLeft:220, padding:"32px 36px", flex:1 }}>
        {page==="home"     && <UserHome user={user} orders={myOrders} onNav={setPage} />}
        {page==="order"    && <UserCreateOrder user={user} garments={garments} showToast={showToast} onDone={()=>{fetchOrders();setPage("orders");}} />}
        {page==="orders"   && <UserOrders orders={myOrders.filter(o=>o.status!=="DELIVERED")} onSelect={setSelOrder} onRefresh={fetchOrders} />}
        {page==="history"  && <UserHistory orders={myOrders.filter(o=>o.status==="DELIVERED")} onSelect={setSelOrder} />}
        {page==="feedback" && <UserFeedbackPage userId={user.id} orders={myOrders} showToast={showToast} />}
      </main>

      {selOrder && (
        <Modal onClose={()=>setSelOrder(null)}>
          <OrderDetail order={selOrder} onClose={()=>setSelOrder(null)}
            userId={user.id} showToast={showToast} onFeedbackDone={fetchOrders} />
        </Modal>
      )}
    </div>
  );
}

function UserHome({ user, orders, onNav }) {
  const active    = orders.filter(o=>o.status!=="DELIVERED");
  const delivered = orders.filter(o=>o.status==="DELIVERED");
  const spent     = orders.reduce((s,o)=>s+o.totalBill,0);

  return (
    <div>
      <div style={{ marginBottom:28 }}>
        <h1 style={{ fontFamily:"'Syne',sans-serif", fontSize:26, fontWeight:800, color:T.text }}>
          Welcome back, {user.name.split(" ")[0]} 👋
        </h1>
        <p style={{ color:T.muted, fontSize:14, marginTop:4 }}>Here's your laundry at a glance.</p>
      </div>

      {/* Stats */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:16, marginBottom:28 }}>
        {[
          { label:"Active Orders", value:active.length,    color:T.accent, icon:"📦" },
          { label:"Delivered",     value:delivered.length, color:T.green,  icon:"✅" },
          { label:"Total Spent",   value:`₹${spent}`,      color:T.gold,   icon:"💰" },
        ].map(s=>(
          <div key={s.label} style={{ ...card(), borderTop:`3px solid ${s.color}` }}>
            <div style={{ fontSize:28 }}>{s.icon}</div>
            <div style={{ fontSize:28, fontWeight:800, color:T.text, marginTop:8 }}>{s.value}</div>
            <div style={{ fontSize:12, color:T.muted, marginTop:4 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Quick actions */}
      <div style={{ display:"flex", gap:12, marginBottom:28 }}>
        <button style={{ ...btn("primary"), padding:"12px 24px" }} onClick={()=>onNav("order")}>
          ➕ Place New Order
        </button>
        <button style={{ ...btn(), padding:"12px 24px" }} onClick={()=>onNav("orders")}>
          📦 Track Orders
        </button>
      </div>

      {/* Active orders mini list */}
      {active.length > 0 && (
        <div style={card()}>
          <div style={{ fontSize:14, fontWeight:700, color:T.aLight, marginBottom:14 }}>Active Orders</div>
          {active.slice(0,3).map(o=>(
            <div key={o.orderId} style={{
              display:"flex", justifyContent:"space-between", alignItems:"center",
              padding:"12px 0", borderBottom:`1px solid ${T.border}`,
            }}>
              <div>
                <div style={{ fontSize:13, fontWeight:600, color:T.text }}>{o.orderId}</div>
                <div style={{ fontSize:11, color:T.muted, marginTop:2 }}>
                  {o.items.map(i=>`${i.name}×${i.quantity}`).join(", ")}
                </div>
              </div>
              <div style={{ textAlign:"right" }}>
                <span style={badge(o.status)}>{STATUS[o.status]?.icon} {o.status}</span>
                <div style={{ fontSize:12, color:T.gold, marginTop:4 }}>₹{o.totalBill}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function UserCreateOrder({ user, garments, showToast, onDone }) {
  const [items, setItems] = useState([{ name:garments[0]?.name||"", quantity:1, pricePerItem: garments[0]?.price||50 }]);
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(null);

  const addItem = () => setItems([...items,{ name:garments[0]?.name||"", quantity:1, pricePerItem:garments[0]?.price||50 }]);
  const removeItem = i => setItems(items.filter((_,idx)=>idx!==i));
  const updateItem = (i,field,val) => {
    const arr=[...items]; arr[i][field]=val;
    if(field==="name"){ const g=garments.find(g=>g.name===val); arr[i].pricePerItem=g?.price||50; }
    setItems(arr);
  };
  const total = items.reduce((s,i)=>s+i.pricePerItem*Number(i.quantity),0);

  const submit = async () => {
    setLoading(true);
    try {
      const r = await fetch(`${API}/orders`,{
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify({ userId:user.id, customerName:user.name, phoneNumber:user.phone, items, notes }),
      });
      const d = await r.json();
      if(!r.ok) return showToast("❌ "+d.error);
      setSuccess(d.order);
    } finally { setLoading(false); }
  };

  if(success) return (
    <div>
      <h1 style={{ fontFamily:"'Syne',sans-serif", fontSize:24, fontWeight:800, color:T.text, marginBottom:8 }}>
        Order Placed! 🎉
      </h1>
      <div style={{ ...card(), maxWidth:460, borderTop:`3px solid ${T.green}` }}>
        <div style={{ fontSize:22, fontWeight:800, color:T.green }}>{success.orderId}</div>
        <div style={{ color:T.muted, fontSize:12, marginBottom:18 }}>Keep this Order ID safe</div>
        <div style={{ display:"grid", gap:12 }}>
          <div><span style={lbl}>ITEMS</span>
            {success.items.map((i,idx)=>(
              <div key={idx} style={{ display:"flex", justifyContent:"space-between", fontSize:14, padding:"4px 0" }}>
                <span>{i.name} × {i.quantity}</span>
                <span style={{ color:T.gold }}>₹{i.pricePerItem*i.quantity}</span>
              </div>
            ))}
          </div>
          <div style={{ display:"flex", justifyContent:"space-between", borderTop:`1px solid ${T.border}`, paddingTop:12 }}>
            <span style={{ fontWeight:700 }}>Total Bill</span>
            <span style={{ fontSize:20, fontWeight:800, color:T.gold }}>₹{success.totalBill}</span>
          </div>
          <div><span style={lbl}>ESTIMATED DELIVERY</span>
            <span style={{ color:T.text, fontSize:14 }}>{success.estimatedDelivery}</span>
          </div>
          <div><span style={lbl}>STATUS</span>
            <span style={badge("RECEIVED")}>📥 RECEIVED</span>
          </div>
        </div>
        <button style={{ ...btn("primary"), marginTop:20, width:"100%" }} onClick={onDone}>
          View My Orders →
        </button>
      </div>
    </div>
  );

  return (
    <div>
      <h1 style={{ fontFamily:"'Syne',sans-serif", fontSize:24, fontWeight:800, color:T.text, marginBottom:6 }}>
        Place New Order
      </h1>
      <p style={{ color:T.muted, fontSize:14, marginBottom:28 }}>Add garments and we'll handle the rest.</p>

      <div style={{ ...card(), maxWidth:540 }}>
        <div style={{ fontSize:13, color:T.muted, marginBottom:16 }}>
          👤 Ordering as: <span style={{ color:T.text, fontWeight:600 }}>{user.name}</span> · {user.phone}
        </div>

        {/* Items */}
        <label style={lbl}>GARMENTS</label>
        {items.map((item,i)=>(
          <div key={i} style={{ display:"flex", gap:8, alignItems:"center", marginBottom:10 }}>
            <select value={item.name} onChange={e=>updateItem(i,"name",e.target.value)}
              style={{ ...inp(), flex:2 }}>
              {garments.map(g=><option key={g.id} value={g.name}>{g.name} (₹{g.price})</option>)}
            </select>
            <input type="number" min="1" value={item.quantity}
              onChange={e=>updateItem(i,"quantity",e.target.value)}
              style={{ ...inp(), flex:1, textAlign:"center" }} placeholder="Qty" />
            <span style={{ color:T.gold, fontSize:13, minWidth:55, textAlign:"right" }}>
              ₹{item.pricePerItem*Number(item.quantity)}
            </span>
            {items.length>1 && (
              <button onClick={()=>removeItem(i)} style={{ ...btn("danger",{padding:"8px 10px",fontSize:12}) }}>✕</button>
            )}
          </div>
        ))}
        <button onClick={addItem} style={{ ...btn("",{fontSize:13, padding:"7px 14px", marginBottom:18}) }}>
          + Add Garment
        </button>

        {/* Notes */}
        <div style={{ marginBottom:18 }}>
          <label style={lbl}>SPECIAL INSTRUCTIONS (optional)</label>
          <textarea value={notes} onChange={e=>setNotes(e.target.value)}
            placeholder="e.g. Handle with care, starch the shirts..."
            style={{ ...inp(), minHeight:72, resize:"vertical" }} />
        </div>

        {/* Bill preview */}
        <div style={{ padding:"14px 16px", background:T.surf, borderRadius:10,
          display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:18 }}>
          <span style={{ color:T.muted, fontSize:13 }}>TOTAL BILL</span>
          <span style={{ fontSize:24, fontWeight:800, color:T.gold }}>₹{total}</span>
        </div>

        <button style={{ ...btn("primary"), width:"100%", padding:"13px" }}
          onClick={submit} disabled={loading}>
          {loading ? "Placing Order..." : "Place Order →"}
        </button>
      </div>
    </div>
  );
}

function UserOrders({ orders, onSelect, onRefresh }) {
  useEffect(()=>{ onRefresh(); },[]);
  return (
    <div>
      <h1 style={{ fontFamily:"'Syne',sans-serif", fontSize:24, fontWeight:800, color:T.text, marginBottom:6 }}>
        My Active Orders
      </h1>
      <p style={{ color:T.muted, fontSize:14, marginBottom:24 }}>Track your order status in real time.</p>
      {orders.length===0 ? (
        <div style={{ ...card(), textAlign:"center", padding:48, color:T.muted }}>
          <div style={{ fontSize:40, marginBottom:12 }}>🧺</div>
          <div>No active orders. Place one!</div>
        </div>
      ) : (
        <div style={{ display:"grid", gap:12 }}>
          {orders.map(o=>(
            <div key={o.orderId} onClick={()=>onSelect(o)} style={{
              ...card(), display:"flex", justifyContent:"space-between",
              alignItems:"center", cursor:"pointer",
              transition:"border .15s",
              borderColor: T.border,
            }}
            onMouseEnter={e=>e.currentTarget.style.borderColor=T.b2}
            onMouseLeave={e=>e.currentTarget.style.borderColor=T.border}>
              <div>
                <div style={{ fontSize:13, fontWeight:700, color:T.aLight }}>{o.orderId}</div>
                <div style={{ fontSize:12, color:T.muted, marginTop:3 }}>
                  {o.items.map(i=>`${i.name}×${i.quantity}`).join(", ")}
                </div>
                <div style={{ fontSize:11, color:T.dim, marginTop:3 }}>
                  Placed: {new Date(o.createdAt).toLocaleDateString()} · Est: {o.estimatedDelivery}
                </div>
              </div>
              <div style={{ textAlign:"right" }}>
                <span style={badge(o.status)}>{STATUS[o.status]?.icon} {o.status}</span>
                <div style={{ fontSize:14, fontWeight:700, color:T.gold, marginTop:6 }}>₹{o.totalBill}</div>
                <div style={{ fontSize:11, color:T.muted, marginTop:4 }}>Tap to view details →</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function UserHistory({ orders, onSelect }) {
  return (
    <div>
      <h1 style={{ fontFamily:"'Syne',sans-serif", fontSize:24, fontWeight:800, color:T.text, marginBottom:6 }}>
        Order History
      </h1>
      <p style={{ color:T.muted, fontSize:14, marginBottom:24 }}>All your delivered orders.</p>
      {orders.length===0 ? (
        <div style={{ ...card(), textAlign:"center", padding:48, color:T.muted }}>
          <div style={{ fontSize:40, marginBottom:12 }}>📋</div>
          <div>No delivered orders yet.</div>
        </div>
      ) : (
        <div style={{ ...card(), padding:0 }}>
          <table style={{ width:"100%", borderCollapse:"collapse" }}>
            <thead>
              <tr>
                {["Order ID","Items","Bill","Delivered On","Feedback",""].map(h=>(
                  <th key={h} style={{ textAlign:"left", padding:"12px 16px", fontSize:11,
                    color:T.muted, letterSpacing:1, textTransform:"uppercase",
                    borderBottom:`1px solid ${T.border}` }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {orders.map(o=>(
                <tr key={o.orderId}
                  onMouseEnter={e=>e.currentTarget.style.background=T.surf}
                  onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                  <td style={{ padding:"12px 16px", fontSize:12, color:T.aLight, fontWeight:700 }}>{o.orderId}</td>
                  <td style={{ padding:"12px 16px", fontSize:12, color:T.muted }}>
                    {o.items.map(i=>`${i.name}×${i.quantity}`).join(", ")}
                  </td>
                  <td style={{ padding:"12px 16px", fontSize:13, color:T.gold, fontWeight:700 }}>₹{o.totalBill}</td>
                  <td style={{ padding:"12px 16px", fontSize:12, color:T.muted }}>
                    {o.deliveredAt ? new Date(o.deliveredAt).toLocaleDateString() : "-"}
                  </td>
                  <td style={{ padding:"12px 16px" }}>
                    {o.hasFeedback
                      ? <span style={{ fontSize:12, color:T.green }}>✅ Given</span>
                      : <span style={{ fontSize:12, color:T.muted }}>Pending</span>}
                  </td>
                  <td style={{ padding:"12px 16px" }}>
                    <button style={btn("",{padding:"5px 12px",fontSize:12})} onClick={()=>onSelect(o)}>
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function UserFeedbackPage({ userId, orders, showToast }) {
  const [feedbacks, setFeedbacks] = useState([]);
  const delivered = orders.filter(o=>o.status==="DELIVERED");

  useEffect(()=>{
    fetch(`${API}/feedback/user/${userId}`).then(r=>r.json()).then(setFeedbacks).catch(()=>{});
  },[userId]);

  const givenIds = feedbacks.map(f=>f.orderId);
  const pending  = delivered.filter(o=>!givenIds.includes(o.orderId));

  return (
    <div>
      <h1 style={{ fontFamily:"'Syne',sans-serif", fontSize:24, fontWeight:800, color:T.text, marginBottom:6 }}>
        My Feedback
      </h1>
      <p style={{ color:T.muted, fontSize:14, marginBottom:24 }}>Rate your experience for delivered orders.</p>

      {pending.length>0 && (
        <>
          <div style={{ fontSize:14, fontWeight:700, color:T.gold, marginBottom:12 }}>
            ⏳ Pending Feedback ({pending.length})
          </div>
          {pending.map(o=>(
            <FeedbackForm key={o.orderId} order={o} userId={userId} showToast={showToast}
              onDone={()=>{
                fetch(`${API}/feedback/user/${userId}`).then(r=>r.json()).then(setFeedbacks);
              }} />
          ))}
        </>
      )}

      {feedbacks.length>0 && (
        <>
          <div style={{ fontSize:14, fontWeight:700, color:T.green, marginBottom:12, marginTop:24 }}>
            ✅ Submitted Feedback ({feedbacks.length})
          </div>
          {feedbacks.map(f=>(
            <div key={f.id} style={{ ...card(), marginBottom:12 }}>
              <div style={{ display:"flex", justifyContent:"space-between", marginBottom:10 }}>
                <div>
                  <div style={{ fontSize:12, color:T.aLight, fontWeight:700 }}>{f.orderId}</div>
                  <div style={{ fontSize:11, color:T.muted, marginTop:2 }}>
                    {new Date(f.createdAt).toLocaleDateString()}
                  </div>
                </div>
              </div>
              <div style={{ display:"flex", gap:20, marginBottom:10 }}>
                <div><div style={{ fontSize:11, color:T.muted, marginBottom:4 }}>OVERALL</div><Stars value={f.overallRating} /></div>
                <div><div style={{ fontSize:11, color:T.muted, marginBottom:4 }}>PRODUCT</div><Stars value={f.productRating} /></div>
                <div><div style={{ fontSize:11, color:T.muted, marginBottom:4 }}>SERVICE</div><Stars value={f.serviceRating} /></div>
              </div>
              {f.comment && <div style={{ fontSize:13, color:T.muted, fontStyle:"italic" }}>"{f.comment}"</div>}
            </div>
          ))}
        </>
      )}

      {pending.length===0 && feedbacks.length===0 && (
        <div style={{ ...card(), textAlign:"center", padding:48, color:T.muted }}>
          <div style={{ fontSize:40, marginBottom:12 }}>⭐</div>
          <div>No delivered orders to rate yet.</div>
        </div>
      )}
    </div>
  );
}

function FeedbackForm({ order, userId, showToast, onDone }) {
  const [ratings, setRatings] = useState({ overall:0, product:0, service:0 });
  const [comment, setComment] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    if(!ratings.overall) return showToast("❌ Please give overall rating");
    setLoading(true);
    try {
      const r = await fetch(`${API}/feedback`,{
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          userId, orderId:order.orderId,
          overallRating:ratings.overall, productRating:ratings.product||ratings.overall,
          serviceRating:ratings.service||ratings.overall, comment,
        }),
      });
      const d = await r.json();
      if(!r.ok) return showToast("❌ "+d.error);
      showToast("✅ Feedback submitted!");
      onDone();
    } finally { setLoading(false); }
  };

  return (
    <div style={{ ...card(), marginBottom:16, border:`1px solid ${T.gold}30` }}>
      <div style={{ fontSize:13, fontWeight:700, color:T.text, marginBottom:4 }}>{order.orderId}</div>
      <div style={{ fontSize:12, color:T.muted, marginBottom:16 }}>
        {order.items.map(i=>`${i.name}×${i.quantity}`).join(", ")} · ₹{order.totalBill}
      </div>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:12, marginBottom:14 }}>
        {[["overall","⭐ Overall"],["product","🎽 Product Quality"],["service","🤝 Service"]].map(([k,label])=>(
          <div key={k}>
            <div style={{ fontSize:11, color:T.muted, marginBottom:6 }}>{label}</div>
            <Stars value={ratings[k]} onChange={v=>setRatings({...ratings,[k]:v})} size={18} />
          </div>
        ))}
      </div>
      <textarea value={comment} onChange={e=>setComment(e.target.value)}
        placeholder="Share your experience (optional)..."
        style={{ ...inp(), minHeight:60, resize:"vertical", marginBottom:12 }} />
      <button style={btn("primary",{padding:"8px 20px",fontSize:13})} onClick={submit} disabled={loading}>
        {loading ? "Submitting..." : "Submit Feedback"}
      </button>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   ORDER DETAIL MODAL (shared user/owner)
═══════════════════════════════════════════════════════════ */
function OrderDetail({ order, onClose, userId, showToast, onFeedbackDone }) {
  const [fbExists, setFbExists] = useState(null);

  useEffect(()=>{
    fetch(`${API}/feedback/order/${order.orderId}`).then(r=>r.json()).then(setFbExists).catch(()=>{});
  },[order.orderId]);

  return (
    <div>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:20 }}>
        <div>
          <div style={{ fontFamily:"'Syne',sans-serif", fontSize:18, fontWeight:800, color:T.text }}>
            {order.orderId}
          </div>
          <div style={{ fontSize:13, color:T.muted, marginTop:3 }}>
            {order.customerName} · {order.phoneNumber}
          </div>
        </div>
        <button onClick={onClose} style={{ background:"none", border:"none", color:T.muted, fontSize:20, cursor:"pointer" }}>✕</button>
      </div>

      {/* Items */}
      <div style={{ marginBottom:16 }}>
        <div style={{ fontSize:11, color:T.muted, letterSpacing:1, marginBottom:8 }}>GARMENTS</div>
        {order.items.map((i,idx)=>(
          <div key={idx} style={{ display:"flex", justifyContent:"space-between", padding:"7px 0", borderBottom:`1px solid ${T.border}` }}>
            <span style={{ fontSize:14 }}>{i.name} × {i.quantity}</span>
            <span style={{ color:T.gold, fontSize:14 }}>₹{i.pricePerItem*i.quantity}</span>
          </div>
        ))}
        <div style={{ display:"flex", justifyContent:"space-between", paddingTop:10, fontWeight:700 }}>
          <span>Total</span>
          <span style={{ color:T.gold, fontSize:18 }}>₹{order.totalBill}</span>
        </div>
      </div>

      {/* Info row */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:16 }}>
        <div style={{ padding:"10px 14px", background:T.surf, borderRadius:8 }}>
          <div style={lbl}>STATUS</div>
          <span style={badge(order.status)}>{STATUS[order.status]?.icon} {order.status}</span>
        </div>
        <div style={{ padding:"10px 14px", background:T.surf, borderRadius:8 }}>
          <div style={lbl}>EST. DELIVERY</div>
          <div style={{ fontSize:14, color:T.text }}>{order.estimatedDelivery}</div>
        </div>
      </div>

      {order.notes && (
        <div style={{ padding:"10px 14px", background:T.surf, borderRadius:8, marginBottom:16 }}>
          <div style={lbl}>NOTES</div>
          <div style={{ fontSize:13, color:T.muted }}>{order.notes}</div>
        </div>
      )}

      {/* Status Timeline */}
      <div style={{ marginBottom:16 }}>
        <div style={{ fontSize:11, color:T.muted, letterSpacing:1, marginBottom:8 }}>STATUS TIMELINE</div>
        <StatusTimeline history={order.statusHistory} />
      </div>

      {/* Feedback section for delivered orders */}
      {order.status==="DELIVERED" && userId && !fbExists && !order.hasFeedback && (
        <div style={{ borderTop:`1px solid ${T.border}`, paddingTop:16 }}>
          <div style={{ fontSize:13, fontWeight:700, color:T.gold, marginBottom:12 }}>⭐ Rate this order</div>
          <FeedbackForm order={order} userId={userId} showToast={showToast}
            onDone={()=>{ setFbExists(true); if(onFeedbackDone) onFeedbackDone(); }} />
        </div>
      )}
      {fbExists && (
        <div style={{ padding:"10px 14px", background:`${T.green}10`, borderRadius:8, border:`1px solid ${T.green}20` }}>
          <div style={{ fontSize:13, color:T.green }}>✅ Feedback submitted for this order</div>
          <div style={{ display:"flex", gap:16, marginTop:8 }}>
            <div><div style={{ fontSize:11, color:T.muted }}>Overall</div><Stars value={fbExists.overallRating} size={16}/></div>
            <div><div style={{ fontSize:11, color:T.muted }}>Product</div><Stars value={fbExists.productRating} size={16}/></div>
            <div><div style={{ fontSize:11, color:T.muted }}>Service</div><Stars value={fbExists.serviceRating} size={16}/></div>
          </div>
          {fbExists.comment && <div style={{ fontSize:12, color:T.muted, marginTop:6, fontStyle:"italic" }}>"{fbExists.comment}"</div>}
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   OWNER PORTAL
═══════════════════════════════════════════════════════════ */
function OwnerPortal({ user, onLogout, showToast }) {
  const [page, setPage] = useState("dashboard");
  const [orders, setOrders] = useState([]);
  const [selOrder, setSelOrder] = useState(null);

  const fetchOrders = useCallback(()=>{
    fetch(`${API}/orders`).then(r=>r.json()).then(d=>setOrders(d.orders||[])).catch(()=>{});
  },[]);

  useEffect(()=>{ fetchOrders(); },[fetchOrders]);

  const nav = [
    { id:"dashboard", icon:"📊", label:"Dashboard"   },
    { id:"orders",    icon:"🧺", label:"All Orders"   },
    { id:"manage",    icon:"🔄", label:"Manage Status" },
    { id:"garments",  icon:"👔", label:"Garments"     },
    { id:"feedback",  icon:"⭐", label:"Feedback"      },
    { id:"users",     icon:"👥", label:"Customers"    },
  ];

  return (
    <div style={{ minHeight:"100vh", background:T.bg, fontFamily:"'Outfit',sans-serif", display:"flex" }}>
      <aside style={{
        width:220, background:T.surf, borderRight:`1px solid ${T.border}`,
        display:"flex", flexDirection:"column", position:"fixed",
        top:0, left:0, height:"100vh", zIndex:100,
      }}>
        <div style={{ padding:"24px 20px 16px", borderBottom:`1px solid ${T.border}` }}>
          <div style={{ fontFamily:"'Syne',sans-serif", fontSize:18, fontWeight:800, color:T.text }}>
            🧺 CleanTrack
          </div>
          <div style={{ fontSize:11, color:T.accent, marginTop:3, letterSpacing:1 }}>OWNER PORTAL</div>
        </div>
        <div style={{ padding:"12px", flex:1 }}>
          {nav.map(n=>(
            <div key={n.id} onClick={()=>setPage(n.id)} style={{
              display:"flex", alignItems:"center", gap:10, padding:"10px 12px",
              borderRadius:10, cursor:"pointer", marginBottom:3,
              background: page===n.id ? `${T.accent}20` : "transparent",
              color: page===n.id ? T.aLight : T.muted,
              fontWeight: page===n.id ? 600 : 400, fontSize:14,
              border: page===n.id ? `1px solid ${T.accent}30` : "1px solid transparent",
              transition:"all .15s",
            }}>
              <span>{n.icon}</span><span>{n.label}</span>
            </div>
          ))}
        </div>
        <div style={{ padding:"16px 20px", borderTop:`1px solid ${T.border}` }}>
          <div style={{ fontSize:13, color:T.text, fontWeight:600 }}>{user.name}</div>
          <div style={{ fontSize:11, color:T.accent, marginTop:2 }}>Store Owner</div>
          <button onClick={onLogout} style={{ ...btn("danger",{padding:"6px 14px",fontSize:12,marginTop:10,width:"100%"}) }}>
            Sign Out
          </button>
        </div>
      </aside>

      <main style={{ marginLeft:220, padding:"32px 36px", flex:1 }}>
        {page==="dashboard" && <OwnerDashboard />}
        {page==="orders"    && <OwnerOrders orders={orders} onSelect={o=>{setSelOrder(o);}} onRefresh={fetchOrders} />}
        {page==="manage"    && <OwnerManage orders={orders} showToast={showToast} onRefresh={fetchOrders} />}
        {page==="garments"  && <OwnerGarments showToast={showToast} />}
        {page==="feedback"  && <OwnerFeedback />}
        {page==="users"     && <OwnerUsers />}
      </main>

      {selOrder && (
        <Modal onClose={()=>setSelOrder(null)}>
          <OwnerOrderDetail order={selOrder} showToast={showToast}
            onClose={()=>setSelOrder(null)} onRefresh={()=>{fetchOrders();setSelOrder(null);}} />
        </Modal>
      )}
    </div>
  );
}

function OwnerDashboard() {
  const [data, setData] = useState(null);
  useEffect(()=>{
    fetch(`${API}/dashboard`).then(r=>r.json()).then(setData).catch(()=>{});
  },[]);
  if(!data) return <div style={{color:T.muted}}>Loading...</div>;

  return (
    <div>
      <h1 style={{ fontFamily:"'Syne',sans-serif", fontSize:26, fontWeight:800, color:T.text, marginBottom:6 }}>Dashboard</h1>
      <p style={{ color:T.muted, fontSize:14, marginBottom:28 }}>Overview of your dry cleaning operations.</p>

      {/* Stats */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:16, marginBottom:28 }}>
        {[
          { label:"Total Orders", value:data.totalOrders,    color:T.accent, icon:"📦" },
          { label:"Revenue",      value:`₹${data.totalRevenue}`, color:T.gold, icon:"💰" },
          { label:"Ready Pickup", value:data.pendingDelivery, color:T.green,  icon:"✅" },
          { label:"Customers",    value:data.totalUsers,      color:T.blue,   icon:"👥" },
        ].map(s=>(
          <div key={s.label} style={{ ...card(), borderTop:`3px solid ${s.color}` }}>
            <div style={{ fontSize:26 }}>{s.icon}</div>
            <div style={{ fontSize:26, fontWeight:800, color:T.text, marginTop:8 }}>{s.value}</div>
            <div style={{ fontSize:12, color:T.muted, marginTop:4 }}>{s.label}</div>
          </div>
        ))}
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16, marginBottom:16 }}>
        {/* Orders by status */}
        <div style={card()}>
          <div style={{ fontSize:14, fontWeight:700, color:T.aLight, marginBottom:16 }}>Orders by Status</div>
          {Object.entries(STATUS).map(([s,cfg])=>{
            const count = data.ordersPerStatus?.[s]||0;
            const pct   = data.totalOrders ? Math.round(count/data.totalOrders*100) : 0;
            return (
              <div key={s} style={{ marginBottom:12 }}>
                <div style={{ display:"flex", justifyContent:"space-between", marginBottom:4 }}>
                  <span style={{ fontSize:13, color:T.text }}>{cfg.icon} {s}</span>
                  <span style={{ fontSize:13, fontWeight:700, color:cfg.color }}>{count}</span>
                </div>
                <div style={{ height:4, background:T.border, borderRadius:2 }}>
                  <div style={{ height:"100%", width:`${pct}%`, background:cfg.color, borderRadius:2, transition:"width .5s" }} />
                </div>
              </div>
            );
          })}
        </div>

        {/* Ratings */}
        <div style={card()}>
          <div style={{ fontSize:14, fontWeight:700, color:T.aLight, marginBottom:16 }}>Customer Ratings</div>
          {[
            ["Overall Rating",  data.avgOverall],
            ["Product Quality", data.avgProduct],
            ["Service",         data.avgService],
          ].map(([label, val])=>(
            <div key={label} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:14 }}>
              <span style={{ fontSize:13, color:T.muted }}>{label}</span>
              <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                {val ? <Stars value={Math.round(Number(val))} size={16}/> : null}
                <span style={{ fontSize:16, fontWeight:800, color:T.gold }}>{val||"—"}</span>
              </div>
            </div>
          ))}
          <div style={{ marginTop:8, padding:"8px 12px", background:`${T.gold}10`,
            borderRadius:8, fontSize:12, color:T.muted }}>
            Based on {data.recentFeedback?.length||0} recent reviews
          </div>
        </div>
      </div>

      {/* Recent orders */}
      <div style={card()}>
        <div style={{ fontSize:14, fontWeight:700, color:T.aLight, marginBottom:14 }}>Recent Orders</div>
        {data.recentOrders?.length===0 && <div style={{ color:T.muted, fontSize:13 }}>No orders yet.</div>}
        {data.recentOrders?.map(o=>(
          <div key={o.orderId} style={{ display:"flex", justifyContent:"space-between", alignItems:"center",
            padding:"10px 0", borderBottom:`1px solid ${T.border}` }}>
            <div>
              <div style={{ fontSize:13, fontWeight:600, color:T.aLight }}>{o.orderId}</div>
              <div style={{ fontSize:11, color:T.muted, marginTop:2 }}>{o.customerName} · {o.phoneNumber}</div>
            </div>
            <div style={{ textAlign:"right" }}>
              <span style={badge(o.status)}>{STATUS[o.status]?.icon} {o.status}</span>
              <div style={{ fontSize:13, color:T.gold, fontWeight:700, marginTop:4 }}>₹{o.totalBill}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function OwnerOrders({ orders, onSelect, onRefresh }) {
  const [filters, setFilters] = useState({ status:"", customerName:"", phone:"", garmentType:"" });

  const fetchFiltered = useCallback(()=>{
    const p = new URLSearchParams();
    Object.entries(filters).forEach(([k,v])=>{ if(v) p.append(k,v); });
    fetch(`${API}/orders?${p}`).then(r=>r.json()).then(d=>{
      // handled by parent but we can refetch locally
    });
    onRefresh();
  },[filters, onRefresh]);

  useEffect(()=>{ fetchFiltered(); },[fetchFiltered]);

  const filtered = orders.filter(o=>{
    if(filters.status && o.status!==filters.status) return false;
    if(filters.customerName && !o.customerName.toLowerCase().includes(filters.customerName.toLowerCase())) return false;
    if(filters.phone && !o.phoneNumber.includes(filters.phone)) return false;
    if(filters.garmentType && !o.items.some(i=>i.name.toLowerCase().includes(filters.garmentType.toLowerCase()))) return false;
    return true;
  });

  return (
    <div>
      <h1 style={{ fontFamily:"'Syne',sans-serif", fontSize:24, fontWeight:800, color:T.text, marginBottom:6 }}>All Orders</h1>
      <p style={{ color:T.muted, fontSize:14, marginBottom:20 }}>View, search and manage all customer orders.</p>

      {/* Filters */}
      <div style={{ display:"flex", gap:10, marginBottom:20, flexWrap:"wrap" }}>
        {[
          ["status","Status","select"],
          ["customerName","Search by name...","text"],
          ["phone","Search by phone...","text"],
          ["garmentType","Filter by garment...","text"],
        ].map(([key,ph,type])=>(
          type==="select" ? (
            <select key={key} value={filters[key]} onChange={e=>setFilters({...filters,[key]:e.target.value})}
              style={{ ...inp(), width:"auto", minWidth:140, padding:"8px 12px" }}>
              <option value="">All Statuses</option>
              {Object.keys(STATUS).map(s=><option key={s} value={s}>{s}</option>)}
            </select>
          ) : (
            <input key={key} value={filters[key]} onChange={e=>setFilters({...filters,[key]:e.target.value})}
              placeholder={ph} style={{ ...inp(), width:"auto", minWidth:160, padding:"8px 12px" }} />
          )
        ))}
        <button onClick={()=>setFilters({status:"",customerName:"",phone:"",garmentType:""})}
          style={btn("",{padding:"8px 14px",fontSize:13})}>Clear</button>
      </div>

      <div style={{ ...card(), padding:0 }}>
        {filtered.length===0 ? (
          <div style={{ textAlign:"center", padding:48, color:T.muted }}>
            <div style={{ fontSize:36, marginBottom:10 }}>🧺</div>No orders found
          </div>
        ) : (
          <table style={{ width:"100%", borderCollapse:"collapse" }}>
            <thead>
              <tr>{["Order ID","Customer","Phone","Items","Bill","Status","Est. Delivery","Action"].map(h=>(
                <th key={h} style={{ textAlign:"left", padding:"12px 14px", fontSize:11,
                  color:T.muted, letterSpacing:1, textTransform:"uppercase",
                  borderBottom:`1px solid ${T.border}` }}>{h}</th>
              ))}</tr>
            </thead>
            <tbody>
              {filtered.map(o=>(
                <tr key={o.orderId}
                  onMouseEnter={e=>e.currentTarget.style.background=T.surf}
                  onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                  <td style={{padding:"12px 14px",fontSize:12,color:T.aLight,fontWeight:700}}>{o.orderId}</td>
                  <td style={{padding:"12px 14px",fontSize:13}}>{o.customerName}</td>
                  <td style={{padding:"12px 14px",fontSize:12,color:T.muted}}>{o.phoneNumber}</td>
                  <td style={{padding:"12px 14px",fontSize:11,color:T.muted}}>
                    {o.items.map(i=>`${i.name}×${i.quantity}`).join(", ")}
                  </td>
                  <td style={{padding:"12px 14px",fontSize:13,fontWeight:700,color:T.gold}}>₹{o.totalBill}</td>
                  <td style={{padding:"12px 14px"}}>
                    <span style={badge(o.status)}>{STATUS[o.status]?.icon} {o.status}</span>
                  </td>
                  <td style={{padding:"12px 14px",fontSize:12,color:T.muted}}>{o.estimatedDelivery}</td>
                  <td style={{padding:"12px 14px"}}>
                    <button style={btn("",{padding:"5px 12px",fontSize:12})} onClick={()=>onSelect(o)}>
                      Manage
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

function OwnerManage({ orders, showToast, onRefresh }) {
  const pending = orders.filter(o=>o.status!=="DELIVERED");

  const updateStatus = async (orderId, status) => {
    const r = await fetch(`${API}/orders/${orderId}/status`,{
      method:"PATCH", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({ status, note:"Updated by owner" }),
    });
    if(r.ok){ showToast("✅ Status updated!"); onRefresh(); }
    else showToast("❌ Failed to update");
  };

  const confirmDelivery = async (orderId) => {
    const r = await fetch(`${API}/orders/${orderId}/confirm`,{ method:"PATCH" });
    if(r.ok){ showToast("✅ Delivery confirmed!"); onRefresh(); }
  };

  return (
    <div>
      <h1 style={{ fontFamily:"'Syne',sans-serif", fontSize:24, fontWeight:800, color:T.text, marginBottom:6 }}>
        Manage Status
      </h1>
      <p style={{ color:T.muted, fontSize:14, marginBottom:24 }}>
        Move orders through the workflow. Confirm deliveries once items reach customers.
      </p>

      {pending.length===0 ? (
        <div style={{ ...card(), textAlign:"center", padding:48, color:T.muted }}>
          <div style={{ fontSize:36, marginBottom:10 }}>🎉</div>
          All orders are delivered!
        </div>
      ) : (
        <div style={{ display:"grid", gap:12 }}>
          {pending.map(o=>(
            <div key={o.orderId} style={{ ...card(), display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:14 }}>
              <div>
                <div style={{ fontSize:13, fontWeight:700, color:T.aLight }}>{o.orderId}</div>
                <div style={{ fontSize:12, color:T.text, marginTop:2 }}>{o.customerName} · {o.phoneNumber}</div>
                <div style={{ fontSize:11, color:T.muted, marginTop:2 }}>
                  {o.items.map(i=>`${i.name}×${i.quantity}`).join(", ")} · ₹{o.totalBill}
                </div>
              </div>
              <div style={{ display:"flex", gap:8, alignItems:"center", flexWrap:"wrap" }}>
                <span style={badge(o.status)}>{STATUS[o.status]?.icon} {o.status}</span>
                {/* Status buttons */}
                {Object.keys(STATUS).filter(s=>s!==o.status).map(s=>(
                  <button key={s} onClick={()=>updateStatus(o.orderId,s)} style={{
                    padding:"6px 12px", borderRadius:8, border:`1px solid ${STATUS[s].color}40`,
                    background:`${STATUS[s].color}15`, color:STATUS[s].color,
                    cursor:"pointer", fontSize:12, fontWeight:600, fontFamily:"inherit",
                  }}>
                    {STATUS[s].icon} {s}
                  </button>
                ))}
                {o.status==="READY" && (
                  <button style={{ ...btn("green",{padding:"6px 16px",fontSize:12}) }}
                    onClick={()=>confirmDelivery(o.orderId)}>
                    ✅ Confirm Delivery
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function OwnerGarments({ showToast }) {
  const [garments, setGarments] = useState([]);
  const [form, setForm] = useState({ name:"", price:"" });
  const [editing, setEditing] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetch_ = () => fetch(`${API}/garments/all`).then(r=>r.json()).then(setGarments).catch(()=>{});
  useEffect(()=>{ fetch_(); },[]);

  const addGarment = async () => {
    if(!form.name||!form.price) return showToast("❌ Name and price required");
    setLoading(true);
    try {
      const r = await fetch(`${API}/garments`,{
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify({ name:form.name, price:Number(form.price) }),
      });
      const d = await r.json();
      if(!r.ok) return showToast("❌ "+d.error);
      showToast("✅ Garment added!");
      setForm({ name:"", price:"" }); fetch_();
    } finally { setLoading(false); }
  };

  const saveEdit = async () => {
    const r = await fetch(`${API}/garments/${editing.id}`,{
      method:"PATCH", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({ name:editing.name, price:Number(editing.price) }),
    });
    if(r.ok){ showToast("✅ Saved!"); setEditing(null); fetch_(); }
  };

  const toggleActive = async (g) => {
    const r = await fetch(`${API}/garments/${g.id}`,{
      method:"PATCH", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({ active:!g.active }),
    });
    if(r.ok){ showToast(`✅ ${g.active?"Deactivated":"Activated"}!`); fetch_(); }
  };

  return (
    <div>
      <h1 style={{ fontFamily:"'Syne',sans-serif", fontSize:24, fontWeight:800, color:T.text, marginBottom:6 }}>
        Garment Management
      </h1>
      <p style={{ color:T.muted, fontSize:14, marginBottom:24 }}>Add, edit or deactivate garment types and their prices.</p>

      {/* Add form */}
      <div style={{ ...card(), marginBottom:20, border:`1px solid ${T.accent}30` }}>
        <div style={{ fontSize:14, fontWeight:700, color:T.aLight, marginBottom:14 }}>Add New Garment</div>
        <div style={{ display:"flex", gap:12, alignItems:"flex-end" }}>
          <div style={{ flex:2 }}>
            <label style={lbl}>GARMENT NAME</label>
            <input style={inp()} placeholder="e.g. Coat" value={form.name}
              onChange={e=>setForm({...form,name:e.target.value})} />
          </div>
          <div style={{ flex:1 }}>
            <label style={lbl}>PRICE (₹)</label>
            <input style={inp()} type="number" placeholder="e.g. 150" value={form.price}
              onChange={e=>setForm({...form,price:e.target.value})} />
          </div>
          <button style={{ ...btn("primary",{padding:"11px 22px",whiteSpace:"nowrap"}) }}
            onClick={addGarment} disabled={loading}>
            + Add
          </button>
        </div>
      </div>

      {/* Table */}
      <div style={{ ...card(), padding:0 }}>
        <table style={{ width:"100%", borderCollapse:"collapse" }}>
          <thead>
            <tr>{["Garment","Price (₹)","Status","Actions"].map(h=>(
              <th key={h} style={{ textAlign:"left", padding:"12px 16px", fontSize:11,
                color:T.muted, letterSpacing:1, textTransform:"uppercase",
                borderBottom:`1px solid ${T.border}` }}>{h}</th>
            ))}</tr>
          </thead>
          <tbody>
            {garments.map(g=>(
              <tr key={g.id}
                onMouseEnter={e=>e.currentTarget.style.background=T.surf}
                onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                <td style={{padding:"12px 16px"}}>
                  {editing?.id===g.id ? (
                    <input value={editing.name} onChange={e=>setEditing({...editing,name:e.target.value})}
                      style={{ ...inp(), width:140 }} />
                  ) : (
                    <span style={{ fontSize:14, fontWeight:600 }}>{g.name}</span>
                  )}
                </td>
                <td style={{padding:"12px 16px"}}>
                  {editing?.id===g.id ? (
                    <input type="number" value={editing.price} onChange={e=>setEditing({...editing,price:e.target.value})}
                      style={{ ...inp(), width:80 }} />
                  ) : (
                    <span style={{ fontSize:14, color:T.gold, fontWeight:700 }}>₹{g.price}</span>
                  )}
                </td>
                <td style={{padding:"12px 16px"}}>
                  <span style={{
                    fontSize:12, fontWeight:700,
                    color: g.active ? T.green : T.red,
                    background: g.active ? `${T.green}15` : `${T.red}15`,
                    padding:"3px 10px", borderRadius:20,
                  }}>
                    {g.active ? "Active" : "Inactive"}
                  </span>
                </td>
                <td style={{padding:"12px 16px"}}>
                  <div style={{ display:"flex", gap:8 }}>
                    {editing?.id===g.id ? (
                      <>
                        <button style={btn("green",{padding:"5px 12px",fontSize:12})} onClick={saveEdit}>Save</button>
                        <button style={btn("",{padding:"5px 12px",fontSize:12})} onClick={()=>setEditing(null)}>Cancel</button>
                      </>
                    ) : (
                      <>
                        <button style={btn("",{padding:"5px 12px",fontSize:12})}
                          onClick={()=>setEditing({...g})}>Edit</button>
                        <button style={{ padding:"5px 12px", borderRadius:8, border:`1px solid ${g.active?T.red:T.green}40`,
                          background: g.active?`${T.red}15`:`${T.green}15`,
                          color: g.active?T.red:T.green, cursor:"pointer", fontSize:12, fontWeight:600, fontFamily:"inherit" }}
                          onClick={()=>toggleActive(g)}>
                          {g.active?"Deactivate":"Activate"}
                        </button>
                      </>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function OwnerFeedback() {
  const [data, setData] = useState({ feedback:[], total:0 });
  useEffect(()=>{
    fetch(`${API}/feedback`).then(r=>r.json()).then(setData).catch(()=>{});
  },[]);

  const avg = (key) => data.feedback.length
    ? (data.feedback.reduce((s,f)=>s+f[key],0)/data.feedback.length).toFixed(1) : "—";

  return (
    <div>
      <h1 style={{ fontFamily:"'Syne',sans-serif", fontSize:24, fontWeight:800, color:T.text, marginBottom:6 }}>
        Customer Feedback
      </h1>
      <p style={{ color:T.muted, fontSize:14, marginBottom:24 }}>All ratings and reviews from customers.</p>

      {/* Rating summary */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:16, marginBottom:24 }}>
        {[
          ["Overall Rating",  avg("overallRating"), T.gold ],
          ["Product Quality", avg("productRating"),  T.green],
          ["Service Rating",  avg("serviceRating"),  T.blue ],
        ].map(([label,val,color])=>(
          <div key={label} style={{ ...card(), textAlign:"center", borderTop:`3px solid ${color}` }}>
            <div style={{ fontSize:32, fontWeight:800, color:T.text }}>{val}</div>
            <div style={{ fontSize:12, color:T.muted, marginTop:4 }}>{label}</div>
            {val!=="—" && <Stars value={Math.round(Number(val))} size={18} />}
          </div>
        ))}
      </div>

      {/* Feedback list */}
      {data.feedback.length===0 ? (
        <div style={{ ...card(), textAlign:"center", padding:48, color:T.muted }}>
          <div style={{ fontSize:36, marginBottom:10 }}>⭐</div>No feedback yet.
        </div>
      ) : (
        <div style={{ display:"grid", gap:12 }}>
          {data.feedback.map(f=>(
            <div key={f.id} style={card()}>
              <div style={{ display:"flex", justifyContent:"space-between", marginBottom:10 }}>
                <div>
                  <div style={{ fontSize:13, fontWeight:700 }}>{f.customerName}</div>
                  <div style={{ fontSize:11, color:T.muted, marginTop:2 }}>
                    {f.orderId} · {new Date(f.createdAt).toLocaleDateString()}
                  </div>
                </div>
                <div style={{ display:"flex", gap:16 }}>
                  {[["Overall",f.overallRating],["Product",f.productRating],["Service",f.serviceRating]].map(([l,v])=>(
                    <div key={l} style={{ textAlign:"center" }}>
                      <div style={{ fontSize:10, color:T.muted, marginBottom:2 }}>{l}</div>
                      <Stars value={v} size={14} />
                    </div>
                  ))}
                </div>
              </div>
              {f.comment && <div style={{ fontSize:13, color:T.muted, fontStyle:"italic", padding:"8px 12px", background:T.surf, borderRadius:8 }}>
                "{f.comment}"
              </div>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function OwnerUsers() {
  const [users, setUsers] = useState([]);
  useEffect(()=>{ fetch(`${API}/users`).then(r=>r.json()).then(setUsers).catch(()=>{}); },[]);

  return (
    <div>
      <h1 style={{ fontFamily:"'Syne',sans-serif", fontSize:24, fontWeight:800, color:T.text, marginBottom:6 }}>
        Customers
      </h1>
      <p style={{ color:T.muted, fontSize:14, marginBottom:24 }}>All registered customers.</p>
      <div style={{ ...card(), padding:0 }}>
        <table style={{ width:"100%", borderCollapse:"collapse" }}>
          <thead>
            <tr>{["Name","Phone","Email","Joined"].map(h=>(
              <th key={h} style={{ textAlign:"left", padding:"12px 16px", fontSize:11,
                color:T.muted, letterSpacing:1, textTransform:"uppercase",
                borderBottom:`1px solid ${T.border}` }}>{h}</th>
            ))}</tr>
          </thead>
          <tbody>
            {users.map(u=>(
              <tr key={u.id}
                onMouseEnter={e=>e.currentTarget.style.background=T.surf}
                onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                <td style={{padding:"12px 16px",fontWeight:600}}>{u.name}</td>
                <td style={{padding:"12px 16px",fontSize:13,color:T.muted}}>{u.phone}</td>
                <td style={{padding:"12px 16px",fontSize:13,color:T.aLight}}>{u.email}</td>
                <td style={{padding:"12px 16px",fontSize:12,color:T.muted}}>
                  {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : "—"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function OwnerOrderDetail({ order, showToast, onClose, onRefresh }) {
  const [note, setNote] = useState("");

  const updateStatus = async (status) => {
    const r = await fetch(`${API}/orders/${order.orderId}/status`,{
      method:"PATCH", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({ status, note }),
    });
    if(r.ok){ showToast("✅ Status updated!"); onRefresh(); }
    else showToast("❌ Failed");
  };

  const confirmDelivery = async () => {
    const r = await fetch(`${API}/orders/${order.orderId}/confirm`,{ method:"PATCH" });
    if(r.ok){ showToast("✅ Delivery confirmed!"); onRefresh(); }
  };

  const deleteOrder = async () => {
    if(!window.confirm("Delete this order?")) return;
    await fetch(`${API}/orders/${order.orderId}`,{ method:"DELETE" });
    showToast("✅ Order deleted"); onRefresh();
  };

  return (
    <div>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:20 }}>
        <div>
          <div style={{ fontFamily:"'Syne',sans-serif", fontSize:18, fontWeight:800, color:T.text }}>{order.orderId}</div>
          <div style={{ fontSize:13, color:T.muted, marginTop:2 }}>{order.customerName} · {order.phoneNumber}</div>
        </div>
        <button onClick={onClose} style={{ background:"none", border:"none", color:T.muted, fontSize:20, cursor:"pointer" }}>✕</button>
      </div>

      {/* Items */}
      <div style={{ marginBottom:16 }}>
        <div style={lbl}>ITEMS</div>
        {order.items.map((i,idx)=>(
          <div key={idx} style={{ display:"flex", justifyContent:"space-between", padding:"7px 0", borderBottom:`1px solid ${T.border}` }}>
            <span style={{ fontSize:13 }}>{i.name} × {i.quantity}</span>
            <span style={{ color:T.gold }}>₹{i.pricePerItem*i.quantity}</span>
          </div>
        ))}
        <div style={{ display:"flex", justifyContent:"space-between", paddingTop:10, fontWeight:700 }}>
          <span>Total Bill</span>
          <span style={{ color:T.gold, fontSize:18 }}>₹{order.totalBill}</span>
        </div>
      </div>

      {/* Status update */}
      <div style={{ marginBottom:16 }}>
        <div style={lbl}>UPDATE STATUS</div>
        <input style={{ ...inp(), marginBottom:10 }} placeholder="Add a note (optional)..."
          value={note} onChange={e=>setNote(e.target.value)} />
        <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
          {Object.entries(STATUS).map(([s,cfg])=>(
            <button key={s} onClick={()=>updateStatus(s)} style={{
              padding:"8px 14px", borderRadius:8,
              border:`1px solid ${cfg.color}40`,
              background: order.status===s ? `${cfg.color}25` : `${cfg.color}10`,
              color:cfg.color, cursor:"pointer", fontSize:12, fontWeight:700,
              fontFamily:"inherit",
              outline: order.status===s ? `1px solid ${cfg.color}` : "none",
            }}>
              {cfg.icon} {s}
            </button>
          ))}
        </div>
      </div>

      {/* Confirm delivery */}
      {order.status==="READY" && !order.deliveryConfirmed && (
        <button style={{ ...btn("green",{width:"100%",padding:"12px",marginBottom:12}) }}
          onClick={confirmDelivery}>
          ✅ Confirm Delivery Sent
        </button>
      )}

      {/* Timeline */}
      <div style={{ marginBottom:14 }}>
        <div style={lbl}>STATUS HISTORY</div>
        <StatusTimeline history={order.statusHistory} />
      </div>

      <button style={{ ...btn("danger",{width:"100%",padding:"10px"}) }} onClick={deleteOrder}>
        🗑 Delete Order
      </button>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   APP ROOT
═══════════════════════════════════════════════════════════ */
export default function App() {
  const [user, setUser] = useState(null);
  const [toast, setToast] = useState({ show:false, msg:"" });

  const showToast = (msg) => {
    setToast({ show:true, msg });
    setTimeout(()=>setToast({ show:false, msg:"" }), 3000);
  };

  const handleLogout = () => setUser(null);

  return (
    <div style={{ fontFamily:"'Outfit',sans-serif" }}>
      <link href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>

      {!user && <AuthScreen onLogin={setUser} showToast={showToast} />}
      {user?.role==="user"  && <UserPortal  user={user} onLogout={handleLogout} showToast={showToast} />}
      {user?.role==="owner" && <OwnerPortal user={user} onLogout={handleLogout} showToast={showToast} />}

      <Toast msg={toast.msg} show={toast.show} />
    </div>
  );
}
